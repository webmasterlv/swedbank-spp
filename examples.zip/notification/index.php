<?php
include '../setup.php';

$result = $gateway -> validatePayment();

if ($result->isSuccess()) {
	$order = $result -> getOrder();
	// Update status of your order by $order -> getId()
}

echo '<p>Result:</p>';
echo '<table border="1">';
echo '<tr><td>Success?</td><td>'.($result -> isSuccess() ? 'Y' : 'N').'</td></tr>';
echo '<tr><td>Status</td><td>'.($result -> getStatus()).'</td></tr>';
echo '<tr><td>Source</td><td>'.($result -> getSource()).'</td></tr>';
echo '<tr><td>Remote code</td><td>'.($result -> getRemoteStatus()).'</td></tr>';
echo '<tr><td>Message</td><td>'.($result -> getMessage()).'</td></tr>';
echo '<tr><td>Reference</td><td>'.($result -> getReference()).'</td></tr>';
echo '<tr><td>Instance</td><td>'.get_class($result).'</td></tr>';
echo '<tr><td>Raw data</td><td><pre>';
var_dump($result);
echo '</pre></td></tr>';
echo '</table>';




