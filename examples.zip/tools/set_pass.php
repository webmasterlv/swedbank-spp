<?php
include '../setup.php';

$newPassword = '123';

$result = $gateway -> setPassword($newPassword);

echo '<p>Result:</p>';
echo '<table border="1">';
echo '<tr><td>Success?</td><td>'.($result -> isSuccess() ? 'Y' : 'N').'</td></tr>';
echo '<tr><td>Status</td><td>'.($result -> getStatus()).'</td></tr>';
echo '<tr><td>Source</td><td>'.($result -> getSource()).'</td></tr>';
echo '<tr><td>Message</td><td>'.($result -> getMessage()).'</td></tr>';
echo '<tr><td>Raw data</td><td><pre>';
var_dump($result);
echo '</pre></td></tr>';
echo '</table>';
