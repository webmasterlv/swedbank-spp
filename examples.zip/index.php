<?php
include 'setup.php';

use Swedbank\SPP\Payment\InternetBank;
use Swedbank\SPP\Payment\PayPal;
use Swedbank\SPP\Payment\CreditCard;
use Swedbank\SPP\Order;
use Swedbank\SPP\Gateway;

$submit	 = filter_input(INPUT_GET, 'submit');

if ($submit) {
	$method		 = filter_input(INPUT_GET, 'method');
	$bank_type	 = filter_input(INPUT_GET, 'bank_type');
	$amount		 = filter_input(INPUT_GET, 'amount');
	$descr		 = filter_input(INPUT_GET, 'descr');

	switch ($method) {
		case 'internet': {
				$paymethod = new InternetBank($bank_type);
				break;
			}
		case 'paypal': {
				$paymethod = new PayPal();
				break;
			}
		case 'cc': {
				$paymethod = new CreditCard();
				break;
			}
	}

	$stmt	 = $db -> prepare("INSERT INTO ".$test_table." SET method=?, amount=?, description=?");
	$stmt -> execute(array($method, $amount, $descr));
	$orderid = $db -> lastInsertId();

	$order	 = new Order($orderid, $descr, $amount);
	$result	 = $gateway -> createTransaction($order, $customer, $paymethod);

	if ($result -> isSuccess()) {
		$reference	 = $result -> getReference();
		$redirectUrl = $result -> getRedirectUrl();

		$stmt = $db -> prepare("UPDATE ".$test_table." SET reference=?, status_code=? WHERE id = ?");
		$stmt -> execute(array($reference, Gateway::STATUS_STARTED, $orderid));

		header("Location: ".$redirectUrl);
		exit;
	} else {
		$data	 = $result -> getData();
		$stmt	 = $db -> prepare("UPDATE ".$test_table." SET status_code=?, status_message=?, gateway_code=? WHERE id = ?");
		$stmt -> execute(array($result -> getStatus(), $result -> getMessage(), $result -> getRemoteStatus(), $orderid));

		echo '<p>Result:</p>';
		echo '<table border="1">';
		echo '<tr><td>Success?</td><td>'.($result -> isSuccess() ? 'Y' : 'N').'</td></tr>';
		echo '<tr><td>Status</td><td>'.($result -> getStatus()).'</td></tr>';
		echo '<tr><td>Source</td><td>'.($result -> getSource()).'</td></tr>';
		echo '<tr><td>Message</td><td>'.($result -> getMessage()).'</td></tr>';
		echo '</table>';
	}
} else {
	?>
	<style>
		ul {
			list-style:none;
		}
	</style>
	<form action="" method="get">
		<input type="hidden" name="submit" value="1" />
		<p>
			Payment method:
		</p>
		<ul>
			<li>
				<input type="radio" checked="checked" value="internet" name="method"> Internet Bank
				<ul>
					<li><input type="radio" checked="checked" value="SW" name="bank_type"> Swedbank</li>
					<li><input type="radio" value="NL" name="bank_type"> Nordea</li>
					<li><input type="radio" value="SV" name="bank_type"> SEB (Latvia)</li>
					<li><input type="radio" value="SL" name="bank_type"> SEB (Lithuania)</li>
					<li><input type="radio" value="DN" name="bank_type"> DNB</li>
					<li><input type="radio" value="DL" name="bank_type"> Danske</li>
					<li><input type="radio" value="CA" name="bank_type"> Citadele</li>
				</ul>
			</li>
			<li><input type="radio" value="paypal" name="method"> PayPal</li>
			<li><input type="radio" value="cc" name="method"> Credit Card</li>
		</ul>
		<p>
			<label>Amount:</label><br />
			<input type="text" name="amount" value="10.00">
		</p>
		<p>
			<label>Description:</label><br />
			<input type="text" name="descr" value="Test payment">
		</p>
		<p>
			<button type="submit">OK</button>
		</p>
	</form>
	<?php
}